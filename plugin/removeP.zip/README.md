# removeP
Plugin to remove of the content's filter 'wpautop' 
## Instructions:

1. Install plugins
2. Active plugins

